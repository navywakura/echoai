"""Prepare S5-F without opening it; run a frozen, uninstrumented examination."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import multiprocessing
from pathlib import Path
import platform
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
OUT = Path(__file__).parent
CONFIG = {"versions": [2, 3], "seeds": list(range(16000, 16060)),
          "reps": [0, 1, 2], "agents": ["v5.7", "v5.8", "random"],
          "budget": 2000, "workers": 4}
SOURCES = ["echo_arc/__init__.py", "echo_arc/agent.py", "echo_arc/runner.py",
           "echo_arc/temporal_memory.py", "echo_arc/temporal_agent.py",
           "echo_arc/temporal_runner.py", "echo_arc/temporal_bench.py",
           "echo_arc/observe.py", "seed/__init__.py", "seed/arc3gym.py",
           "tests/test_temporal_memory.py", "tests/test_temporal_arc.py",
           "tests/test_h1h3_exam.py",
           "docs/ECHO45-H1-H3-DESIGN.md", "docs/ECHO45-H1-H3-EXAM-DESIGN.md",
           "lab/temporal/h1h3-20260927/development-start.json",
           "lab/temporal/h1h3-20260927/completion.json",
           "lab/temporal/h1h3-20260927/final-test-verification.json",
           "lab/temporal/h1h3-20260927/compatibility-verification.json",
           "lab/temporal/h1h3-exam-20260927/evaluate.py"]


def read(path):
    return json.loads(path.read_text())


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def runtime():
    return {"python": platform.python_version(),
            **{p: importlib.metadata.version(p) for p in ("numpy", "arcengine", "arc-agi")}}


def assert_protected():
    start = read(ROOT / "lab/temporal/h1h3-20260927/development-start.json")
    assert all(file_hash(ROOT / p) == h for p, h in start["protected"].items())
    assert file_hash(ROOT / "docs/ECHO45-H1-H3-DESIGN.md") == start["design_sha256"]


def prepare():
    assert_protected()
    completion = read(ROOT / "lab/temporal/h1h3-20260927/completion.json")
    # The current actor must be the tested actor, including the click guard.
    for p in SOURCES:
        if p in completion["current_sources"] and not p.startswith("docs/"):
            assert file_hash(ROOT / p) == completion["current_sources"][p], p
    expected = {"origin": "RESERVED_EXAM_S5F", "configuration": CONFIG,
                "runtime": runtime(), "sources": {p: file_hash(ROOT / p) for p in SOURCES}}
    path = OUT / "freeze.json"
    if path.exists():
        frozen = read(path)
        assert {k: frozen[k] for k in expected} == expected, "freeze changed"
        return frozen
    frozen = dict(expected, prepared=datetime.now(timezone.utc).isoformat())
    save(path, frozen)
    return frozen


def verify_freeze():
    frozen = read(OUT / "freeze.json")
    assert frozen["configuration"] == CONFIG and frozen["runtime"] == runtime()
    assert all(file_hash(ROOT / p) == h for p, h in frozen["sources"].items()), "source changed"
    assert_protected()
    return frozen


def check_record(rec):
    assert len(rec["actions"]) + 1 == len(rec["frames"]) == len(rec["levels"])
    assert rec["levels"][0] == 0
    increments = [i for i in range(1, len(rec["levels"])) if rec["levels"][i] > rec["levels"][i - 1]]
    assert len(increments) == rec["levels_completed"] == len(rec["actions_per_level"])
    assert sum(a == ["R", 0, None] for a in rec["actions"]) >= rec["resets"]
    assert len(rec["actions"]) - rec["resets"] <= rec["budget"]
    # Automatic resets are excluded from the historical per-level counter.
    per_level, count, resets = [], 0, 0
    for i, act in enumerate(rec["actions"], 1):
        automatic = act == ["R", 0, None] and rec["levels"][i] == rec["levels"][i - 1]
        # Agent reset actions are counted; their distinction is stored below.
        if i - 1 in rec["automatic_reset_indices"]:
            assert automatic
            resets += 1
        else:
            count += 1
        if rec["levels"][i] > rec["levels"][i - 1]:
            per_level.append(count)
            count = 0
    assert resets == rec["resets"] and per_level == rec["actions_per_level"]
    from echo_arc import runner
    score = runner.official_game_score(per_level, rec["baseline"])
    assert abs(score - rec["score"]) < 1e-10


class ResetCounter:
    """Track only runner reset accounting, without tracing the agent."""
    def __init__(self, env):
        self.env, self.started, self.game_over = env, False, False
        self.emitted = 0
        self.automatic = []

    def reset(self):
        if self.started:
            if self.game_over:
                self.automatic.append(self.emitted)
            self.emitted += 1
        self.started, self.game_over = True, False
        return self.env.reset()

    def step(self, action, data=None):
        obs = self.env.step(action, data=data)
        if obs is not None:
            self.emitted += 1
            self.game_over = obs.state.name == "GAME_OVER"
        return obs


def one(job):
    name, version, seed, rep, budget, path, frozen_digest, observed = job
    from echo_arc import agent, runner
    from echo_arc.temporal_runner import play
    from echo_arc.temporal_bench import _gym_env
    agent._COMP_CACHE.clear()
    env = _gym_env(version, seed)
    counted = ResetCounter(env)
    journal = None
    if observed:
        from echo_arc.observe import Journal
        journal = Journal(Path(path).with_name("arc-decisions.jsonl"))
        journal.write(kind="start", origin="DEVELOPMENT", agent=name, budget=budget)
        journal.write(kind="game", game=env.game_id)
    try:
        rec = play(counted, budget, runner.seed_for(env.game_id, rep), agent_name=name, journal=journal)
    finally:
        if journal is not None:
            journal.write(kind="end", status="complete")
            journal.close()
    # An agent can also choose R,0. Detect automatic resets from the actual
    # GAME_OVER/reset call sequence instead of inferring them from the action.
    automatic = counted.automatic
    assert counted.emitted == len(rec["actions"])
    assert len(automatic) == rec["resets"]
    rec.update(origin="DEVELOPMENT" if observed else "RESERVED_EXAM_S5F",
               agent=name, version=version, seed=seed, rep=rep, game=env.game_id,
               family=env.game.fam, baseline=env.baseline_actions, budget=budget,
               score=runner.official_game_score(rec["actions_per_level"], env.baseline_actions),
               source_digest=frozen_digest, automatic_reset_indices=automatic)
    check_record(rec)
    path = Path(path)
    save(path, rec)
    return {"record": str(path.relative_to(ROOT)), "sha256": file_hash(path),
            "agent": name, "version": version, "seed": seed, "rep": rep,
            "family": rec["family"], "levels": rec["levels_completed"],
            "score": rec["score"], "decisions": len(rec["actions"]) - rec["resets"],
            "resets": rec["resets"]}


def measure(folder, cases, frozen, observed=False):
    assert not folder.exists(), "measurement already exists; never overwrite an examination"
    folder.mkdir(parents=True)
    jobs = []
    for name, version, seed, rep in cases:
        path = folder / name / f"v{version}-{seed}-r{rep}" / "record.json"
        jobs.append((name, version, seed, rep, CONFIG["budget"] if not observed else 150,
                     str(path), digest(frozen), observed))
    rows = []
    with ProcessPoolExecutor(max_workers=CONFIG["workers"],
                             mp_context=multiprocessing.get_context("spawn")) as pool:
        pending = [pool.submit(one, job) for job in jobs]
        for future in as_completed(pending):
            row = future.result()
            rows.append(row)
            # Exam progress reveals completion counts, not per-game scores.
            print(json.dumps({"stage": folder.name, "done": len(rows), "of": len(jobs)}), flush=True)
    rows.sort(key=lambda r: (r["agent"], r["version"], r["seed"], r["rep"]))
    verify_freeze()
    save(folder / "records.json", rows)
    return rows


def checks(validation, totals, replay_ok):
    old, new = totals["v5.7"], totals["v5.8"]
    families = ["K1", "K2", "K3", "K4", "C1", "C2", "M1"]
    return {
        "F1": all(v["levels"] == v["solver_levels"] == 300 for v in validation.values())
              and set(validation[2]["families"]) == set(families)
              and set(validation[3]["families"]) == {"H1", "H2", "H3", "H4"},
        "F2": totals["random"]["levels"] * 100 < 15 * 1800,
        "F3": all(new["families"].get(f, 0) > old["families"].get(f, 0) for f in ("H1", "H3")),
        "F4": all(new["families"].get(f, 0) >= old["families"].get(f, 0)
                  for f in families + ["H2", "H4"]) and new["scores"][2] >= old["scores"][2],
        "F5": new["scores"][3] > old["scores"][3],
        "F6": replay_ok,
    }


def run():
    frozen = verify_freeze()
    assert not (OUT / "opened.json").exists(), "cohort already opened; preserve it"
    save(OUT / "opened.json", {"opened": datetime.now(timezone.utc).isoformat(),
                              "freeze_sha256": file_hash(OUT / "freeze.json")})
    start = time.monotonic()
    from seed import arc3gym as gym
    validation = {}
    for version in CONFIG["versions"]:
        gym.VERSION = version
        validation[version] = gym.validate(CONFIG["seeds"])
    save(OUT / "validation.json", validation)
    cases = [(a, v, s, r) for a in CONFIG["agents"] for v in CONFIG["versions"]
             for s in CONFIG["seeds"] for r in CONFIG["reps"]]
    rows = measure(OUT / "measurement", cases, frozen)
    replay = measure(OUT / "independent-replay", [("v5.8", v, s, 0)
                     for v in CONFIG["versions"] for s in CONFIG["seeds"]], frozen)
    original = {(r["version"], r["seed"]): r for r in rows
                if r["agent"] == "v5.8" and r["rep"] == 0}
    replay_ok = all(read(ROOT / r["record"]) == read(ROOT / original[r["version"], r["seed"]]["record"])
                    for r in replay)
    totals = {}
    for name in CONFIG["agents"]:
        members = [r for r in rows if r["agent"] == name]
        families = sorted({r["family"] for r in members})
        totals[name] = {"levels": sum(r["levels"] for r in members),
                        "families": {f: sum(r["levels"] for r in members if r["family"] == f) for f in families},
                        "scores": {v: sum(r["score"] for r in members if r["version"] == v) / 180
                                   for v in CONFIG["versions"]},
                        "decisions": sum(r["decisions"] for r in members),
                        "resets": sum(r["resets"] for r in members)}
    for row in rows + replay:
        path = ROOT / row["record"]
        assert file_hash(path) == row["sha256"]
        check_record(read(path))
    verify_freeze()
    verdicts = checks(validation, totals, replay_ok)
    result = {"origin": "RESERVED_EXAM_S5F", "checks": verdicts,
              "green": all(verdicts.values()), "totals": totals,
              "records": len(rows), "exact_replays": len(replay),
              "seconds": time.monotonic() - start, "freeze_sha256": file_hash(OUT / "freeze.json"),
              "closed": datetime.now(timezone.utc).isoformat(), "S6_status": "RED_UNCHANGED"}
    save(OUT / "audit.json", result)
    print(json.dumps(result), flush=True)


def main():
    if not __debug__:
        raise RuntimeError("evaluation requires assertions enabled")
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("stage", choices=("prepare", "smoke", "run"))
    args = ap.parse_args()
    if args.stage == "prepare":
        frozen = prepare()
        print(json.dumps({"prepared": True, "opened": (OUT / "opened.json").exists(),
                          "sources": len(frozen["sources"]), "runtime": frozen["runtime"]}))
    elif args.stage == "smoke":
        frozen = verify_freeze()
        assert not (OUT / "opened.json").exists(), "smoke only before opening exam"
        cases = [(name, 3, seed, 0) for name in ("v5.7", "v5.8") for seed in (0, 4)]
        rows = measure(OUT / "smoke-training", cases, frozen, observed=True)
        save(OUT / "smoke-verification.json", {"origin": "DEVELOPMENT", "records": len(rows),
              "training_seeds": [0, 4], "reserved_cohort_opened": False,
              "sources_unchanged": True, "records_valid": True})
    else:
        run()


if __name__ == "__main__":
    main()
